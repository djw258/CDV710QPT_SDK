======================================================

              11n single chip MP

======================================================

This file contains information about system requirement, 
new features, installation, and warning issues of 
this version. 

======================================================

              System Requirement

======================================================

* Operating System:
  - Windows 2000, Windows XP, Windows Vista



======================================================

              Installation Notes

======================================================

* To install the utility, one can use the InstallShiled
  wizard, setup.exe and follow steps below:

  Step 1. Plug WLAN adapter on your system.

  Step 2. Uninstall previously installed MP and reboot.
          (Please follow instructions in next section about 
          uninstallation.)

  Step 3. Install new version MP.

======================================================

              Note.

======================================================

