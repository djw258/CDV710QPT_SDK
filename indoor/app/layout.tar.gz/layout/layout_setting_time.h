#ifndef _LAYOUT_SETTING_TIME_H_
#define _LAYOUT_SETTING_TIME_H_
void setting_time_first_enter_set_flag(char isfirst);
#endif
