#ifndef _WIFI_INFO_H_
#define _WIFI_INFO_H_

/***********************************************
 ** 作者: leo.liu
 ** 日期: 2023-2-2 13:46:56
 ** 说明: 设置连接wifi的信息
 ***********************************************/
void connected_wifi_info_setting(const void *info);

void layout_setting_user_wifi_display_mode_set(char mode);
#endif
