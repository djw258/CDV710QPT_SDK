#ifndef _USER_UGPRADE_H_
#define _USER_UGPRADE_H_
#include <stdbool.h>

bool outdoor_network_upgrade(const char *ip);


bool outdoor_network_enable_status_get(void);
#endif